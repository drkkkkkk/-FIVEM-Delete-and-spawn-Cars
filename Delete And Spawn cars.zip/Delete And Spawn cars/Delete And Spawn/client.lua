RegisterCommand('car', function(source, args)
-- account for the argument not being passed
local vehicleName = args[1] or 'adder'

-- check if the vehicle acctually exists
if not IsModelInCdimage(VehicleName) or not IsModelAVehicle(vehicleName) then
TriggerEvent('chat:addMessage', {
           args = {'Vehicle not recognised ' .. vehicleName}
})
return
     end
	 
	 -- Load the model
	 RequestModel(VehicleName)
	 
	 -- wait for the model to load
	 while not HasModelLoaded(VehicleName) do 
	  wait (500)
	  end
	  
	  -- Get the  player's  position
	  local playerPed = PlayerPedId() -- Get the local player ped
	  local pos = GetEntityCoords(playerPed) -- Get position of the local player ped
	  
	  -- create the  vehicle
	  local vehicle = CreateVehicle(vehicleName, pos.x, pos.y, pos.z, GetEntityHeading(PlayerPed), true,false)
	  
	  --set the player ped into the vehicle's driver seat
	  SetPedIntoVehicle(playerPed, vehicle, -1)
	  
	  -- give vehicle back to the game (This'll make the game decide when to despawn the vehicle)
	  SetEntityAsNoLongerNeeded(vehicle)
	  
	  -- release the  model
	  SetModelAsNoLongerNeeded(VehicleName)
	  
	  -- Tell the player
	  TriggerEvent('Chat:addMessage', {
	  args = {'You have spawned a ' .. VehicleName.. '.' }
	  })	  
end, false)

RegisterCommand('dv', function()
-- get the local player ped
local PlayerPed = PlayerPedId ()
-- get the vehicle the player is in
local vehicle = GetVehiclePedIsIn(playerPed, false)
-- delete the vehicle 
DeleteEntity(Vehicle)
end, false)

fx_verison 'cerulean'
game 'gta5'

author 'Drk'
description 'Spawn And Delete Vehicles by drk'
version '1.0'

client_script 'client.lua'
